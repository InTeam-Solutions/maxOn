# Initio MVP - Умный персональный ассистент

Telegram-бот на базе микросервисной архитектуры с контекстно-осведомленным AI агентом.

## 🎯 Возможности

- ✅ **События** - создание, поиск, редактирование событий в календаре
- ✅ **Цели** - диалоговая постановка целей с разбивкой на микрошаги
- ✅ **Товары** - поиск и добавление товаров, привязанных к целям
- ✅ **Контекстный AI** - агент помнит историю диалога, активные цели и ближайшие события
- ✅ **Многошаговые диалоги** - state machine для сложных сценариев

## 🏗️ Архитектура

```
┌─────────────────┐
│  Telegram Bot   │
│  (API Gateway)  │
└────────┬────────┘
         │
    ┌────▼─────────┐
    │ Orchestrator │ (координация)
    └─┬──┬────┬────┘
      │  │    │
  ┌───▼──▼────▼───┐
  │ Context │ LLM │ Core │
  │ Service │ Srv │ Srv  │
  └─────────┴─────┴──────┘
          │
    ┌─────▼──────┐
    │ PostgreSQL │
    │   Redis    │
    │ RabbitMQ   │
    └────────────┘
```

### Сервисы

1. **Core Service** (:8004) - Business logic (Events, Goals, Products, Cart)
2. **Context Service** (:8002) - Управление памятью, история диалогов, сессии
3. **LLM Service** (:8003) - OpenAI интеграция с контекстными промптами
4. **API Gateway** (:8080) - Telegram bot handler (в разработке)
5. **Orchestrator** (:8001) - Координация сервисов и state machine (в разработке)
6. **Worker** - Фоновые задачи (напоминания, повторяющиеся события) (в разработке)

## 🚀 Быстрый старт

### Требования

- Docker & Docker Compose

### 1. Клонировать репозиторий

```bash
cd /Users/asgatakmaev/Desktop/business/Initio
```

### 2. Настроить переменные окружения

Отредактируйте `.env` файл:

```bash
# ОБЯЗАТЕЛЬНО замените эти значения:
TELEGRAM_BOT_TOKEN=your_telegram_bot_token_here
OPENAI_API_KEY=your_openai_api_key_here
```

Как получить токены:
- **Telegram**: @BotFather → /newbot
- **OpenAI**: https://platform.openai.com/api-keys

### 3. Запустить все сервисы

```bash
docker compose up -d
```

### 4. Проверить статус

```bash
docker compose ps
```

Должны работать:
- ✅ postgres (5432)
- ✅ redis (6379)
- ✅ rabbitmq (5672, 15672)
- ✅ core (8004)
- ✅ context (8002)
- ✅ llm (8003)

### 5. Просмотреть логи

```bash
# Все сервисы
docker compose logs -f

# Конкретный сервис
docker compose logs -f core
```

### 6. API документация

После запуска доступна Swagger UI:

- Core Service: http://localhost:8004/docs
- Context Service: http://localhost:8002/docs
- LLM Service: http://localhost:8003/docs

## 📋 Основные команды

```bash
docker compose up -d              # Запустить все сервисы
docker compose down               # Остановить все сервисы
docker compose ps                 # Статус контейнеров
docker compose logs -f            # Просмотр логов всех сервисов
docker compose logs -f core       # Логи конкретного сервиса
docker compose restart core       # Перезапустить сервис
docker compose build              # Пересобрать образы
docker compose down -v            # Удалить все (⚠️ потеря данных!)
```

### Подключение к базам данных

```bash
# PostgreSQL
docker compose exec postgres psql -U initio -d initio

# Redis
docker compose exec redis redis-cli
```

## 🗄️ База данных

### Схема

**Core Service:**
- `events` - события календаря
- `goals` - цели пользователя
- `steps` - микрошаги целей
- `products` - товары
- `cart_items` - корзина

**Context Service:**
- `user_profiles` - профили пользователей
- `conversation_messages` - история диалогов
- `session_states` - состояния сессий


## 🧪 Тестирование

### Ручное тестирование API

**Создать событие:**
```bash
curl -X POST http://localhost:8004/api/events \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "123",
    "title": "Встреча",
    "date": "2025-10-01",
    "time": "15:00"
  }'
```

**Получить контекст пользователя:**
```bash
curl http://localhost:8002/api/context/123
```

**Парсинг сообщения через LLM:**
```bash
curl -X POST http://localhost:8003/api/parse \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Покажи мои события на завтра",
    "context": {
      "profile": {"timezone": "Europe/Moscow"},
      "active_goals": [],
      "upcoming_events": []
    }
  }'
```

## 📊 Мониторинг

### RabbitMQ Management UI

http://localhost:15672

- Username: `initio`
- Password: (из `.env` → `RABBITMQ_PASSWORD`)

### Health Checks

```bash
curl http://localhost:8004/health  # Core
curl http://localhost:8002/health  # Context
curl http://localhost:8003/health  # LLM
```

## 🔧 Разработка

### Добавление нового поля в Event

1. Обновить модель: `services/core/app/models/event.py`
2. Обновить схему: `shared/schemas/events.py`
3. Перезапустить сервис: `docker compose restart core`

### Изменение промптов

Промпты в Jinja2 шаблонах:
- `services/llm/app/prompts/system.py` - основной system prompt
- `services/llm/app/prompts/summarizer.py` - суммаризация ответов
- `services/llm/app/prompts/goal_coach.py` - генерация шагов целей

После изменения перезапустите сервис:
```bash
docker compose restart llm
```

### Очистка кеша LLM

```bash
curl -X DELETE http://localhost:8003/api/cache
```

## 🐛 Troubleshooting

### Ошибка "POSTGRES_PASSWORD is required"

Проверьте `.env` файл - должна быть установлена переменная `POSTGRES_PASSWORD`.

### Ошибка "OpenAI API key not found"

Установите `OPENAI_API_KEY` в `.env` файле.

### Контейнер не запускается

```bash
# Проверить логи
docker compose logs <service_name>

# Пересобрать контейнер
docker compose build <service_name>
docker compose up -d <service_name>
```

### База данных не создается

```bash
# Пересоздать volumes
docker compose down -v
docker compose up -d
```

## 📚 Документация

См. `CLAUDE.md` для детальной архитектуры и руководства по разработке.

## 🚧 Roadmap

- [ ] Orchestrator Service - координация и state machine
- [ ] API Gateway - полноценный Telegram bot
- [ ] Worker Service - фоновые задачи и напоминания
- [ ] Product Search - интеграция с маркетплейсами
- [ ] Recurring Events - автогенерация повторяющихся событий
- [ ] Integration Tests
- [ ] Deploy на продакшен (Kubernetes)

## 📝 Лицензия

MIT

## 👨‍💻 Разработка

Создано с помощью Claude Code.

---

**Нужна помощь?** Проверьте логи: `docker compose logs -f`