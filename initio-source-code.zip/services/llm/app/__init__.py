"""LLM Service - OpenAI integration with context-aware prompts"""
__version__ = "0.1.0"