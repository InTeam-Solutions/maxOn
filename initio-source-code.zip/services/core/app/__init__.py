"""Core Service - Business logic for Events, Goals, Products, Cart"""
__version__ = "0.1.0"