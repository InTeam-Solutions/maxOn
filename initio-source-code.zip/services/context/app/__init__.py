"""Context Service - User context and conversation memory"""
__version__ = "0.1.0"