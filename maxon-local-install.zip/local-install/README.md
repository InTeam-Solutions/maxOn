# maxOn - Локальная установка

Этот пакет содержит всё необходимое для запуска maxOn локально на любом компьютере.

## Требования

1. **Docker Desktop** - установите с [docker.com](https://www.docker.com/products/docker-desktop/)
2. **Telegram Bot Token** - получите от [@BotFather](https://t.me/BotFather)
3. **OpenAI API Key** - получите на [platform.openai.com](https://platform.openai.com/api-keys)

## Быстрый старт

### 1. Настройте переменные окружения

Откройте файл `.env` и замените следующие значения:

```bash
# Замените на ваш токен от @BotFather
MAX_BOT_TOKEN=YOUR_TELEGRAM_BOT_TOKEN_HERE

# Замените на ваш OpenAI API ключ
OPENAI_API_KEY=YOUR_OPENAI_API_KEY_HERE
```

**Опционально:** Измените timezone если нужно:
```bash
USER_TIMEZONE=Europe/Moscow  # Измените на ваш часовой пояс
```

### 2. Запустите все сервисы

Откройте терминал в папке `local-install` и выполните:

```bash
docker compose up -d
```

Это запустит все сервисы:
- PostgreSQL (база данных)
- Redis (кеш)
- API Gateway (Telegram бот)
- Orchestrator (координатор)
- LLM Service (обработка языка)
- Core Service (бизнес-логика)
- Context Service (управление контекстом)
- Calendar Service (календарь и события)

### 3. Проверьте статус

Проверьте что все контейнеры запущены:

```bash
docker compose ps
```

Посмотрите логи:

```bash
# Все сервисы
docker compose logs -f

# Только бот
docker compose logs -f api-gateway

# Только ошибки
docker compose logs -f | grep ERROR
```

### 4. Используйте бота

Откройте Telegram и отправьте `/start` вашему боту!

## Команды управления

### Остановить все сервисы
```bash
docker compose down
```

### Перезапустить все сервисы
```bash
docker compose restart
```

### Перезапустить конкретный сервис
```bash
docker compose restart api-gateway
```

### Просмотреть логи конкретного сервиса
```bash
docker compose logs -f api-gateway
```

### Удалить все данные и начать заново
```bash
docker compose down -v
docker compose up -d
```

## Структура проекта

```
local-install/
├── services/              # Все микросервисы
│   ├── api-gateway/      # Telegram бот (порт не открыт наружу)
│   ├── orchestrator/     # Координатор запросов (8001)
│   ├── llm/             # LLM обработка (8003)
│   ├── core/            # Бизнес-логика (8004)
│   ├── context/         # Управление контекстом (8002)
│   └── calendar/        # Календарь и ICS (7132)
├── shared/              # Общие библиотеки
├── docker-compose.yml   # Конфигурация Docker
├── .env                # Переменные окружения
└── README.md           # Эта инструкция
```

## Порты сервисов

- PostgreSQL: `5432`
- Redis: `6379`
- Orchestrator: `8001`
- Context: `8002`
- LLM: `8003`
- Core: `8004`
- Calendar: `7132`

## Доступ к базе данных

Если нужно подключиться к PostgreSQL:

```bash
Host: localhost
Port: 5432
Database: maxon
User: maxon
Password: maxon_strong_password_2025
```

Или через Docker:
```bash
docker compose exec postgres psql -U maxon -d maxon
```

## Доступ к календарю

Calendar service доступен по адресу:
```
http://localhost:7132
```

ICS файлы доступны по:
```
http://localhost:7132/calendar/external/user/{user_id}/events.ics
```

## Troubleshooting

### Бот не отвечает
1. Проверьте что `MAX_BOT_TOKEN` правильный в `.env`
2. Проверьте логи: `docker compose logs api-gateway`
3. Убедитесь что все сервисы запущены: `docker compose ps`

### Ошибки базы данных
1. Пересоздайте базу: `docker compose down -v && docker compose up -d`
2. Проверьте что PostgreSQL запущен: `docker compose ps postgres`

### Ошибки LLM
1. Проверьте что `OPENAI_API_KEY` правильный в `.env`
2. Проверьте баланс на OpenAI аккаунте
3. Проверьте логи: `docker compose logs llm`

### Порты заняты
Если порт уже используется, измените его в `docker-compose.yml`:
```yaml
ports:
  - "НОВЫЙ_ПОРТ:СТАРЫЙ_ПОРТ"
```

## Обновление

Чтобы обновить код:

1. Остановите сервисы: `docker compose down`
2. Замените папки `services` и `shared` на новые версии
3. Запустите заново: `docker compose up -d --build`

## Поддержка

Если возникли проблемы:
1. Проверьте логи: `docker compose logs -f`
2. Убедитесь что Docker Desktop запущен
3. Проверьте что все переменные в `.env` заполнены
4. Попробуйте пересоздать контейнеры: `docker compose down -v && docker compose up -d`

---

**Готово!** Ваш maxOn бот работает локально 🚀
