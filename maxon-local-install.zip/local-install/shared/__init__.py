"""Shared library for Initio microservices"""
__version__ = "0.1.0"