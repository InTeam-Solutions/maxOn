"""Service layer for calendars application."""
