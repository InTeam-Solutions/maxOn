"""Calendar service package."""
